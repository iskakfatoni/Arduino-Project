--------------------------------------------------
#credit by dani_ardianto_Rajacell
--------------------------------------------------
#modified by dani @ Dec 2016
--------------------------------------------------
#for http://www.belajarduino.com
--------------------------------------------------
#support us on https://www.tokopedia.com/rajacell
--------------------------------------------------
#contact me via fb : https://www.facebook.com/dani.ardianto.rajacell